#! /usr/bin/env sh

cd openplm
zip -r ../openplm.xpi .
cd ..


