//pref("extensions.openplm.boolpref", false);
//pref("extensions.openplm.intpref", 0);
pref("extensions.openplm.server", "http://localhost:8000/");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.openplm@openplm.org.description", "chrome://openplm/locale/overlay.properties");
